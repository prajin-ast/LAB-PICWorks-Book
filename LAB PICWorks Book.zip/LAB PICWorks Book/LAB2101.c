/*******************************************************************************
* File        : LAB2101.c
* Purpose     : I2C MASTER
* Author      : Prajin Palangsantikul
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Copyright (c) 2006 APPSOFTTECH CO.,LTD.
*******************************************************************************/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A

/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // Serial port
#use I2C(master,sda=PIN_C4,scl=PIN_C3)  // I2C Bus module

/****************************************************************** Constants */
#define PIC_Slave_ID  0xa0    // PIC16F877A Slave address 0xa0


/************************************************************* Main Functions */
void main(void)
{
    printf("\r\n\nPIC I2C Master  ");
    set_tris_b(0x00);

    delay_ms(1000);

    i2c_start();                // Start condition
    i2c_write(PIC_Slave_ID);    // Device address

    //send data
    i2c_write(0x01);   delay_ms(110);   // address
    i2c_write(0xAA);   delay_ms(110);   // data

    i2c_write(0x02);   delay_ms(110);   // address
    i2c_write(0xA0);   delay_ms(110);   // data

    i2c_write(0x03);   delay_ms(110);   // address
    i2c_write(0x0A);   delay_ms(110);   // data

    i2c_stop();                 // Stop condition

    output_high(PIN_B0);

    while (TRUE)                // Loop nothing
        ;
}
/*************************** End of $Workfile: $ ******************************/
