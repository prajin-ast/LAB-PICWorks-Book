/*******************************************************************************
* Workfile    : LAB0402.c
* Purpose     : 7-Segments LED Display (Two-Digit Counter)
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Other Files :
* Ref         :
*******************************************************************************/

/*********************************************************************** NOTE */
/*
* Configure the LED 7 Segments as follows:
* LED seg a   Pin B0
* LED seg b   Pin B1
* LED seg c   Pin B2
* LED seg d   Pin B3
* LED seg e   Pin B4
* LED seg f   Pin B5
* LED seg g   Pin B6
* LED seg dp  Pin b7
*/


/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A


/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)


/***************************************************************** Data types */
BYTE CONST LED_MAP[17] = {0x3F, 0x06, 0x5B, 0x4F, 0x66,  //0,1,2,3,4
                          0x6D, 0x7D, 0x07, 0x7F, 0x6F,  //5,6,7,8,9
                          0x77, 0x7C, 0x39, 0x5E, 0x79,  //A,b,C,d,E
                          0x71, 0x80};                   //F,.


/*********************************************************** Display_LED7Segs */
/** Display Digit to LED 7-Segments */
void Display_LED7Segs(char c)        //                                      (1)
{
    int i;
    
    for (i=0;i<100;i++) {            // Count display
        output_d(LED_MAP[c/10]);     // Show Digit column 2
        output_low(PIN_A1);          // Enable digit 2 
        output_high(PIN_A0);         // Disable ditit 1
        delay_ms(1);
        output_d(LED_MAP[c%10]);     // Show Digit column 1
        output_low(PIN_A0);          // Enable digit 1
        output_high(PIN_A1);         // Disable digit 2
        delay_ms(1);
    }        
}

/************************************************************* Main Functions */
void main(void)
{
    int i=0;                   //                                            (2)
    
    set_tris_a(0x00);          // Port a all input
    set_tris_d(0x00);          // Port d all output

    while (TRUE) {
        Display_LED7Segs(i++); // Dispaly Number        
        if (i>99) {            // Clear count for start new                  (3)
            i = 0;
        }
    }
}
/*************************** End of $Workfile: $ ******************************/
