/*******************************************************************************
* File        : LAB1501.c
* Purpose     : PCF8574A I2C Bus
* Author      : Prajin Palangsantikul
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Copyright (c) 2006 APPSOFTTECH CO.,LTD.
*******************************************************************************/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A


/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)
#use I2C(master,sda=PIN_C4 ,scl=PIN_C3)  // I2C Bus module                   (1)

// 01110000, PCF8574A:000 Slave Address (bit1-bit3)
#define PCF8574A_ID  0x70                //                                  (2)


/************************************************************* PCF8574A Wirte */
void PCF8574A_Write(int dat)    //                                           (3)  
{
    i2c_start();                // Send I2C Start Transfer                   
    i2c_write(PCF8574A_ID);     // Send identifier I2C address - Write       
    i2c_write(dat);             // Send data                                 
    i2c_stop();                 // Send I2C Stop Transfer
}

/************************************************************** PCF8574A Read */
int PCF8574A_Read(void)         //                                           (4)
{
	int inData;

	i2c_start();                // Send I2C Start Transfer                   
    i2c_write(PCF8574A_ID+1);   // Send identifier I2C address - Read        
    inData = i2c_read(0);       // Read data , Not ACK                       
    i2c_stop();                 // Send I2C Stop Transfer                    
    delay_ms(200);
    return(inData);             // return data 
}

/************************************************************* Main Functions */
void main(void)
{
    int OutData, InData;

	PCF8574A_Write(0x00);           // clear port                            (5)  

	while (TRUE) {
		InData = PCF8574A_Read();   // Read data
		InData &= 0xF0;             // And Data                              (6)
		OutData = swap(InData);     // Swap bit                              (7)
		PCF8574A_Write(OutData);    // Out data
   }
}
/*************************** End of $Workfile: $ ******************************/
