/*******************************************************************************
* File        : LAB1201.c
* Purpose     : Analog Comparator Module
* Author      : Prajin Palangsantikul
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Copyright (c) 2006 APPSOFTTECH CO.,LTD.
*******************************************************************************/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A
#device ADC=10                    // set 10 bit ADC                          


/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // Serial port 


/******************************************************************* COMP_ISR */
#int_comp                         //                                         (1)                                          
void COMP_ISR()
{
    printf("C2OUT= %d   \r\n",C2OUT);
}

/************************************************************* Main Functions */
void main()
{
    enable_interrupts(GLOBAL);
    enable_interrupts(INT_COMP);
	
    /** Setup analog comparator	*/
    /** input RA0 , RA3 output C1OUT/AN4 */
    /** input RA1 , RA2 output C2OUT/AN5 */
    setup_comparator(A0_A3_A1_A2_OUT_ON_A4_A5); //                           (2)
	
    printf("Analog Comparator module test...    \r\n");
    printf("Two Independent Comparators mode    \r\n");
	
    while (TRUE) {
        printf("C2OUT= %d   \r\n",C2OUT);                                    (3)
        delay_ms(500);
    }
}
/*************************** End of $Workfile: $ ******************************/
