/*******************************************************************************
* Workfile    : LAB0904.c
* Purpose     : Counter 0
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Other Files :
* Ref         :
*******************************************************************************/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A


/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)


/***************************************************************** Timer0 ISR */
#INT_TIMER0                       
void timer0_ISR(void)             
{
    output_toggle(PIN_A0);        // Output toggle A0                        (1) 
    set_timer0(250);              // Set Count 250                           (2)
}

/************************************************************* Main Functions */
void main()
{
    /** Set Interrupt */
    enable_interrupts(GLOBAL);
    enable_interrupts(INT_TIMER0);

    /** Setup Counter0 mode Low to High count with 2 prescaler */
    setup_timer_0(RTCC_EXT_L_TO_H| RTCC_DIV_2);  //                          (3)                       
    set_timer0(250);           // Start Count 250                            (4)

    /** Set Direction port */
    set_tris_a(0x10);          // Port RA4 input only                        (5)

    output_low(PIN_A0);        // Clear RA0

    while (TRUE) {             // Loop forever
        ;
    }
}
/************************** End of $Workfile:  $ ******************************/
