/*******************************************************************************
* Workfile    : LAB0906.c
* Purpose     : Watchdog Timer
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Other Files :
* Ref         :
*******************************************************************************/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A


/************************************************ Setting configuration fuses */
#fuses HS,WDT,NOPROTECT,NOLVP     // Configuration word                      (1)
#use delay(clock=20000000)        // Change OSC here (default 20MHz)


/************************************************************* Main Functions */
void main()
{
    /** Setup Watchdog timer */
    setup_wdt(WDT_2304MS);      // wdt wake-up 2304 ms                       (2)

    /** Set Direction port */
    set_tris_a(0x00);           // port a all output

    output_a(0x00);             // clear port d                              (3)
    output_high(PIN_A0);        // set high
    delay_ms(1000);
    output_low(PIN_A0);         // set low

    while (TRUE) {
        output_toggle(PIN_A1);  // toogle LED                                (4)
        delay_ms(1000);
        restart_wdt();          // Reset wdt                                 (5)
    }
}
/************************** End of $Workfile:  $ ******************************/
