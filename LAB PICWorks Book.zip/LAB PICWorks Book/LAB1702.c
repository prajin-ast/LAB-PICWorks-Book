/*******************************************************************************
* File        : LAB1702.c
* Purpose     : Visual Basic Control
* Author      : Prajin Palangsantikul
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Copyright (c) 2006 APPSOFTTECH CO.,LTD.
*******************************************************************************/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A


/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // Serial port

/******************************************************************** RxD ISR */
// RS232 receive data available
#INT_RDA
void RxD_ISR(void)
{
    char ch;

    ch = getc();

    switch(ch) {
        case '0':
            output_toggle(PIN_B0);
        break;
        case '1':
            output_toggle(PIN_B1);
        break;
        case '2':
            output_toggle(PIN_B2);
        break;
        case '3':
            output_toggle(PIN_B3);
        break;
        case '4':
            output_toggle(PIN_B4);
        break;
        case '5':
            output_toggle(PIN_B5);
        break;
        case '6':
            output_toggle(PIN_B6);
        break;
        case '7':
            output_toggle(PIN_B7);
        break;
        default:
            putc(ch);
            return;
    }
}

/************************************************************* Main Functions */
void main(void)
{
    enable_interrupts(GLOBAL);
    enable_interrupts(INT_RDA);     

    while (TRUE);                       // loop nothing

}
/*************************** End of $Workfile: $ ******************************/
