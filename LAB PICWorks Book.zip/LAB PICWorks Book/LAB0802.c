/*******************************************************************************
* Workfile    : LAB0802.c
* Purpose     : Interrupt On Change
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Other Files :
* Ref         :
*******************************************************************************/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A


/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)


/************************************************************** On Change ISR */
#INT_RB                           //                                         (1)
void On_Change_ISR(void)          //                                         (2)
{
    if (!input(PIN_B4)) {         //                                         (3)
        output_toggle(PIN_A2);    // output toggle only RB4 interrupt CN
    }
    output_toggle(PIN_A1);        // output toggle all interrupt CN          (4)
    delay_ms(200);                // debound
}

/******************************************************************* Init_MCU */
/** Initialize Config MCU */
void Init_MCU(void)
{
    /** Set Interrupt */
    enable_interrupts(GLOBAL);   //                                          (5)
    enable_interrupts(INT_RB);   // set interrupt on change                  (6)

    /** Set Direction port */
    set_tris_b(0xF0);            // port b RB0-RB3 output, RB4-RB7 input     (7)
    set_tris_a(0x00);            // port a output all
}

/************************************************************* Main Functions */
void main()
{
    Init_MCU();                  // Initialize Config MCU
    output_a(0x00);              // Clear RA
    
    while (TRUE) {               //                                          (8)
        output_toggle(PIN_A0);   // output toggle
        delay_ms(1000);
    }
}
/************************** End of $Workfile:  $ ******************************/
