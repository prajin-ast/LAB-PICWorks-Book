/*******************************************************************************
* File        : LAB1401.c
* Purpose     : USART Module
* Author      : Prajin Palangsantikul
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Copyright (c) 2006 APPSOFTTECH CO.,LTD.
*******************************************************************************/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A


/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)         (1)
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // Serial port               (2)

#include <stdlib.h>               //                                         (3)           
#include "input.c"                //                                         (4)


/************************************************************* Main Functions */
void main()
{
    long a,b,result;
    char opr;

    while (TRUE) {
        printf("\r\nEnter the first number: ");
        a = get_long();           //                                         (5)
  
        do {
            printf("\r\nEnter the operator(+,-,*,/): ");
            opr = getc();         //                                         (6)
        }while(!isamoung(opr,"+-*/"));
    
        printf("\r\nEnter the second number: ");
        b = get_long();

        switch (opr) {            //                                         (7)
        case '+': result = a+b; break;
        case '-': result = a-b; break;
        case '*': result = a*b; break;
        case '/': result = a/b; break;  
        }
        printf("\r\nThe result is %lu ",result);
  }
}
/*************************** End of $Workfile: $ ******************************/
