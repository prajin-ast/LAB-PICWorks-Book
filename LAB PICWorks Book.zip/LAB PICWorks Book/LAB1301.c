/*******************************************************************************
* File        : LAB1301.c
* Purpose     : EEPROM Memory
* Author      : Prajin Palangsantikul
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Copyright (c) 2006 APPSOFTTECH CO.,LTD.
*******************************************************************************/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A


/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // Serial port

#define  MAX_DATA_EEPROM   256    // Data EEPROM in PIC16F877                (1)


/************************************************************* Main Functions */
void main()
{
    int16 addr, buffer;                           //                         (2)
    int i=0;

    printf("Wirte EEPROM\r\n");

    for (addr=0;addr<MAX_DATA_EEPROM;addr++)      //                         (3)
        write_eeprom(addr,addr);                  // wirte eeprom

    printf("Read EEPROM\r\n");

    for (addr=0; addr<MAX_DATA_EEPROM-1; addr++) {//                         (4)
        buffer = read_eeprom(addr);               // read eeprom
        printf ("[%c:%x] ", buffer,buffer);

        if (i++>8) {                              //                         (5)
            puts("");
            i = 0;
        }
    }

    while (TRUE)
        ;
}
/*************************** End of $Workfile: $ ******************************/



