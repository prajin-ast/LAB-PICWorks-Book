******************************************************************************
* Workfile    : LAB0907.c
* Purpose     : Two switch button/Interrupt Timer
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Other Files :
* Ref         :
*******************************************************************************/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A


/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)

int counter=0;                      // variable for counter in timer1


/***************************************************************** Timer1 ISR */
// use oscillator 20 MHZ prescaler 8
// timer1 is 16bit counter overflow is 105 ms
#int_timer1
void timer1_isr()
{
    // counter tick ever 525 ms
    if(counter++>4)                 // if counter = 5 -> 5x105=525ms
    {
        output_toggle(PIN_B0);      // toggle
        counter=0;                  // clear for new counter
    }
}

/************************************************************* Main Functions */
void main(void)
{
    int sw2;

    // set interrupt timer1
    enable_interrupts(GLOBAL);
    enable_interrupts(INT_TIMER1);

    sw2 = 0;

    while (1) {

        if(!input(PIN_A0))              // if key down sw1
        {
            counter=0;                  // start count
            // set up timer 0 & enable timer1 prescaler 8
            setup_timer_1(T1_INTERNAL|T1_DIV_BY_8);
        } // end if pin_a0

        if(!input(PIN_A1))                          // if key down
        {
            sw2 = sw2 + 1;                          // counter up
            if(sw2 == 1)  output_high(PIN_B1);      // ON
            if(sw2 == 2)  output_high(PIN_B2);      // ON
            if(sw2 == 3)  output_high(PIN_B3);      // ON
            if(sw2 == 4)  output_high(PIN_B4);      // ON
            if(sw2 == 5)
            {
                sw2 = 0;                        // clear status sw2
                setup_timer_1(T1_DISABLED);     // disable timer1
                output_low(PIN_B0);             // Off all
                output_low(PIN_B1);
                output_low(PIN_B2);
                output_low(PIN_B3);
                output_low(PIN_B4);
            }
            while(!input(PIN_A1))       // wait for key up
            ;
            delay_us(20);               // debound
        } // end if pin_a1

    } // end loop while
}
/*************************** End of $Workfile: $ ******************************/
