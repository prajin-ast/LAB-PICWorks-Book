/*******************************************************************************
* File        : LAB1504.c
* Purpose     : MC14489B (SPI Bus)
* Author      : Prajin Palangsantikul
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Copyright (c) 2006 APPSOFTTECH CO.,LTD.
*******************************************************************************/

/******************************************************************* Includes */
#include <16F877A.h>             	// PIC16F877A device

/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)
#TYPE long=32                     //                                   (1)

// connect MC14489B pin
#define MC14489B_SELECT PIN_C0	  // ENB
#define MC14489B_DI     PIN_C5	  // DI
#define MC14489B_CLK    PIN_C3	  // CLK


/************************************************************** init MC14489B */
void init_MC14489B(unsigned char config)   //                          (2)
{
    output_low(MC14489B_DI);
    output_low(MC14489B_CLK);
    output_low(MC14489B_SELECT);

    // Setup SPI Module
    setup_spi(SPI_MASTER|SPI_L_TO_H|SPI_XMIT_L_TO_H|SPI_CLK_DIV_16);
    output_low(MC14489B_SELECT);
    spi_write(config);
    output_high(MC14489B_SELECT);
}

/******************************************************** Write Data MC14489B */
void WriteData_MC14489B(unsigned long content) //                      (3)
{
    output_low(MC14489B_SELECT);
    spi_write(content>>16);
    spi_write(content>>8);
    spi_write(content);
    output_high(MC14489B_SELECT);
}

/************************************************************* Main Functions */
void main()
{
    unsigned long dat;
    int1 togle=0;

    set_tris_b(0x00);


    init_mc14489B(0x41); // Initialize MC14489


    while (1) {
        WriteData_MC14489B(0x012345);
        delay_ms(500);
    }
}
/*************************** End of $Workfile: $ ******************************/
