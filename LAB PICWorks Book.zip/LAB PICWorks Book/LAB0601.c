/*******************************************************************************
* Workfile    : LAB0601.c
* Purpose     : DC Motor Control
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : CCS C Compiler
* Target      : PIC16F877A
* Ref         :
*******************************************************************************/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A


/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)

#define MOTOR_LEFT   PIN_A0       //                                         (1)
#define MOTOR_RIGHT  PIN_A1


/***************************************************************** Prototypes */
void Delay_Seconds(int i);
void Motor_Forward(int speed, int16 time_drive);
void Motor_Backword(int speed, int16 time_drive);
void Motor_stop_sec(int sec);


/************************************************************** Delay Seconds */
/** Delay Seconds */
void Delay_Seconds(int i)         //                                         (2)
{
    for (;i>0;i--) {
        delay_ms(1000);
    }
}

/************************************************************* Delay microsec */
/** Delay 10 us */
void Delay_10us(int i)            //                                         (3)
{
    for (;i>0;i--) {
        delay_us(10);
    }
}

/************************************************************** Motor control */
/** Driver motor forware, backword, stop */
/** Motor_Forward */
void Motor_Forward(int speed, int16 time_drive)  //                          (4)
{
    output_bit(MOTOR_RIGHT,0);    // motor right stop
    time_drive *= 10;

    for (; time_drive>0; time_drive--) {
        output_bit(MOTOR_LEFT,1);     // start
        Delay_10us(speed);            // speed up * 10us
        output_bit(MOTOR_LEFT,0);
        Delay_10us(1);                // delay 10 us
    }
}

/** Motor_Backword */
void Motor_Backword(int speed, int16 time_drive)  //                         (5)
{
    output_bit(MOTOR_LEFT,0);     // motor left stop
    time_drive *= 10;

    for (; time_drive>0; time_drive--) {
        output_bit(MOTOR_RIGHT,1);     // motor right start
        Delay_10us(speed);             // speed up * 10us
        output_bit(MOTOR_RIGHT,0);     //
        Delay_10us(1);                 // delay 10 us
    }
}

/** Motor_Stop */
void Motor_stop_sec(int sec)           //                                    (6)
{
    output_bit(MOTOR_RIGHT,0);         // stop
    output_bit(MOTOR_LEFT,0);          // stop
    Delay_Seconds(sec);
}

/************************************************************** Main Function */
void main()
{
    set_tris_a(0x00);              // port a all output
    Motor_stop_sec(1);             // Stop motor 1s

    while (TRUE) {
        Motor_Forward(100, 100);   //                                        (7)
        Motor_stop_sec(2);         //                                        (8)
        Motor_Backword(100, 100);  //                                        (9)
        Motor_stop_sec(2);
    }
}
/************************** End of $Workfile:  $ ******************************/
