/*******************************************************************************
* File        : LAB2102.c
* Purpose     : I2C SLAVE
* Author      : Prajin Palangsantikul
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Copyright (c) 2006 APPSOFTTECH CO.,LTD.
*******************************************************************************/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A

/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // Serial port
#use i2c(SLAVE, SDA=PIN_C4, SCL=PIN_C3, address=0xa0)

/****************************************************************** Constants */
typedef enum {NOTHING, CONTROL_READ,
              ADDRESS_READ, READ_COMMAND_READ} I2C_STATE;

I2C_STATE fState;
BYTE address, buffer[0x10];

int1 hook =0;

/************************************************************** SSP Interrupt */
#INT_SSP
void ssp_interupt ()
{
    BYTE incoming;
   
    if (i2c_poll() == FALSE) {
        printf("\n\r i2c poll active \n\r ");
        if (fState == ADDRESS_READ) {   // i2c_poll() returns false on the
            i2c_write (buffer[address]);// interrupt receiving the second
            // command byte for random read operation
            fState = NOTHING;           
        }
    } else {
        incoming = i2c_read();
        if (fState == NOTHING) {
            fState = ADDRESS_READ;
        } else
            if (fState == ADDRESS_READ) {
                    address = incoming;
                    fState = CONTROL_READ;
            } else
                if (fState == CONTROL_READ) {
                    buffer[address] = incoming;
                    fState = ADDRESS_READ;
                    if (address == 0x03)
                        fState = NOTHING;
                    hook = 1;
                }
    }
}

/************************************************************* Main Functions */
void main(void)
{
    int i;

    fState = NOTHING;               // Init fState
    address = 0x00;                 // Set Address 0x00

    for (i=0;i<0x10;i++)            // Loop clear buffer
        buffer[i] = 0x00;

    enable_interrupts(GLOBAL);
    enable_interrupts(INT_SSP);     // Set SSP Interrupt 

    while (TRUE) {                  // Loop forever
        while(hook) {
            hook =0;
            printf("address:%x data:%X   \n\r",address,buffer[address]);
        }
    }
}
/*************************** End of $Workfile: $ ******************************/
