/*******************************************************************************
* File        : EX_PIC-C.c
* Purpose     : PIC C Programming Example
* Author      : Prajin Palangsantikul
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Copyright (c) 2006 APPSOFTTECH CO.,LTD.
*******************************************************************************/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A


/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // standard output


/************************************************************* Main Functions */
void main(void)
{
    set_tris_a(0xF0);              // Set port RA0-RA3 output, RA4-RA5 input
    printf("TEST Toggle LED\r\n"); // print to serial port                                  
  
    while (TRUE) {
        output_high(PIN_A0);       // Output logic 1 or High
        delay_ms(1000);            // Delay approximate 1s
        output_low(PIN_A0);        // Output logic 0 or Low
        delay_ms(1000);       
  }
}
/*************************** End of $Workfile: $ ******************************/
