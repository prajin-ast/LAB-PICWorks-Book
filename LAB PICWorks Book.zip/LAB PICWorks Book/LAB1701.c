/*******************************************************************************
* File        : LAB1701.c
* Purpose     : HyperTerminal Control
* Author      : Prajin Palangsantikul
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Copyright (c) 2006 APPSOFTTECH CO.,LTD.
*******************************************************************************/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A


/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // Serial port


int led_status[8]={0,0,0,0,0,0,0,0};
short int hook_rx=0;


/******************************************************************** RxD ISR */
// RS232 receive data available
#INT_RDA
void RxD_ISR(void)
{
    char ch,i;

    ch = getc();
    i = ch - '0';       // Select pin status

    switch(ch) {
        case '0':
            output_toggle(PIN_B0);
        break;
        case '1':
            output_toggle(PIN_B1);
        break;
        case '2':
            output_toggle(PIN_B2);
        break;
        case '3':
            output_toggle(PIN_B3);
        break;
        case '4':
            output_toggle(PIN_B4);
        break;
        case '5':
            output_toggle(PIN_B5);
        break;
        case '6':
            output_toggle(PIN_B6);
        break;
        case '7':
            output_toggle(PIN_B7);
        break;
    }
    led_status[i] = !led_status[i];     // Set status pin On/Off
    hook_rx = 1;
}

/************************************************************* Main Functions */
void main(void)
{
    enable_interrupts(GLOBAL);
    enable_interrupts(INT_RDA);     

    printf("\f\rLED PIN : B0   B1   B2   B3   B4   B5   B6   B7   B8\n");
    printf("\rStatus  : 0    0    0    0    0    0    0    0    0");

    while (TRUE) {                  // loop forever
        if (hook_rx) {
            printf("\f\rLED PIN : B0   B1   B2   B3   B4   B5   B6   B7\n");
            printf("\rStatus  : %2d   %2d   %2d   %2d   %2d   %2d   %2d   %2d",
                    led_status[0],led_status[1],led_status[2],led_status[3],
                    led_status[4],led_status[5],led_status[6],led_status[7]);
            hook_rx = 0;
        }
   }
}
/*************************** End of $Workfile: $ ******************************/
