/*******************************************************************************
* File        : LAB1801.c
* Purpose     : rand function
* Author      : Prajin Palangsantikul
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Copyright (c) 2006 APPSOFTTECH CO.,LTD.
*******************************************************************************/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A


/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // Serial port

#define RAND_MAX  16             // max number random
#include <STDLIB.H>


/************************************************************* Main Functions */
void main(void)
{
    unsigned long number;
    int i;

    setup_timer_0(RTCC_INTERNAL|RTCC_DIV_256);

    // this will create a new random seed based on the current
    srand(get_Timer0());    // time counter (wich is pretty random per se)

    for (i=0; i<10; i++) {
        number = rand();
        printf ("%ld  ", number);
    }

    while (TRUE);           // loop nothing

}
/*************************** End of $Workfile: $ ******************************/
