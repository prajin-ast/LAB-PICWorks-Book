/*******************************************************************************
* Workfile    : LAB0602_2.c
* Purpose     : Stepper Motor Control (Full Step 2-Phase)
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Other Files :
* Ref         :
*******************************************************************************/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A


/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)

#define STEP_M_OUTPUT(x)    output_c(x)   //                                 (1)

int fs2p[4] = { 0x0C,0x06,0x03,0x09 };    // Data Full Step 2-Phase          (2)

/***************************************************************** Prototypes */
void Delay_Seconds(int i);
void Delay_1ms(int16 i);
void fw_step(int16 step, int dl);
void rw_step(int16 step, int dl);


/************************************************************** Delay Seconds */
/** Delay Seconds */
void Delay_Seconds(int i)         //                                         (3)
{
    for (;i>0;i--) {
        delay_ms(1000);
    }
}

/******************************************************************* Delay ms */
/** Delay ms */
void Delay_1ms(int16 i)           //                                         (4)
{
    if (i<40) i = 40;             // Minimun Step (default)
    for (;i>0;i--) {
        delay_ms(1);
    }
}

/************************************************************** Motor control */
/** Driver motor forware, backword */
/** Forward Step */
void fw_step(int16 step, int dl)  //                                         (5)
{    
    int n = 0;
    
    while(step--) {
        STEP_M_OUTPUT(fs2p[n]); 
        if (n++ == 3) 
            n = 0;
        Delay_1ms(dl);
    }
}

/** Reward Step */
void rw_step(int16 step, int dl)  //                                         (6)
{
    int n = 3;
    
    while(step--) {
        STEP_M_OUTPUT(fs2p[n]);         
        if (n-- == 0) 
            n = 3;
        Delay_1ms(dl);
    }
}

/************************************************************** Main Function */
void main()
{
    set_tris_c(0x00);          // Port C all output

    while (TRUE) {
        fw_step(10, 40);       // Clockwise
        Delay_Seconds(5);
        rw_step(10, 40);       // Counter-Clockwise
        Delay_Seconds(5);
    }
}
/************************** End of $Workfile:  $ ******************************/
