/*******************************************************************************
* File        : LAB1503.c
* Purpose     : 24LC16 Serial EEPROM
* Author      : Prajin Palangsantikul
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Copyright (c) 2006 APPSOFTTECH CO.,LTD.
*******************************************************************************/

/******************************************************************* Includes */
#include <16F877A.h>             	// PIC16F877A device

/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP     // Configuration word
#use delay(clock=20000000)          // Change OSC here (default 20MHz)
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // Serial port
#use I2C(master, sda=PIN_C4, scl=PIN_C3)        // I2C Bus module

#include "2416.c"                 // Library  0xA0:Address EEPROM 24LC16     (1)

/************************************************************** Main Function */
void main(void)
{
    int16 i;
    int dat;

    init_ext_eeprom();               // Init External EEPROM                 (2)

    printf("TEST 24LC16B EEPROM\n\r");

    printf("\n\r Write...EXT EEPROM");
    for(i=0;i<255;i++)
        write_ext_eeprom(i, i);      // Wirte data to Ext EEPROM             (3)

    printf("\n\r Read...EXT EEPROM\n\r");
    for(i=0;i<255;i++) {
        dat = read_ext_eeprom(i);    // Read data from Ext EEPROM            (4)
        printf("%u  ,  ",dat);
    }

    while(TRUE) {                    // Loop forever
        ;
    }
}
/*************************** End of $Workfile: $ ******************************/
