/*******************************************************************************
* Workfile    : LAB0901.c
* Purpose     : Basic Timer0
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Other Files :
* Ref         :
*******************************************************************************/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A


/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)


/***************************************************************** Data types */
unsigned int tick=0;              //                                         (1)


/***************************************************************** Timer0 ISR */
#INT_TIMER0                       //                                         (2)
void Timer0_ISR(void)
{
    tick++;                       //                                         (3)
    if (tick>75) {                //                                         (4)
        output_toggle(PIN_A0);    // Toggle bit
        tick = 0;
    }
}

/************************************************************* Main Functions */
void main(void)
{
    enable_interrupts(GLOBAL);      // Set global interrupt
    enable_interrupts(INT_TIMER0);  // Set timer0 interrupt                  (5)

    /** Setup Timer0 mode tick every 51.2 us => 1 s = tick 76 (Overflow) */
    setup_timer_0(RTCC_INTERNAL| RTCC_DIV_256);   //                         (6)
    set_timer0(0);                  // Clear Timer0

    set_tris_a(0x00);               // Set port a all output
    output_low(PIN_A0);             // Clear RA0

    while (TRUE) {                  // Loop forever                          (7)
        ;
    }
}
/*************************** End of $Workfile: $ ******************************/
