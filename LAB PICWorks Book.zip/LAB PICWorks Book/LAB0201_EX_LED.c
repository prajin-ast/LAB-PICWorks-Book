/*******************************************************************************
* File        : EX_LED.c
* Purpose     : On/Off LED Example
* Author      : Prajin Palangsantikul
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Copyright (c) 2006 APPSOFTTECH CO.,LTD.
*******************************************************************************/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A

/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)

/************************************************************* Main Functions */
void main(void)
{
    set_tris_a(0x00);              // Set port RA output
  
    while (TRUE) {
        output_high(PIN_A0);       // Output logic 1 or High
        delay_ms(1000);            // Delay approximate 1s
        output_low(PIN_A0);        // Output logic 0 or Low
        delay_ms(1000);       
  }
}
/*************************** End of $Workfile: $ ******************************/
