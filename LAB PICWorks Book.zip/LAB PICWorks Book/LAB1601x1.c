/*******************************************************************************
* File        : LAB1601x1.c
* Purpose     : 1-Wire Bus (DS18B20 - Temperature digital)
* Author      : Prajin Palangsantikul
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Copyright (c) 2006 APPSOFTTECH CO.,LTD.
*******************************************************************************/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A


/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // Serial port

// PIN B0 for 1-Wire bus
#include "touch.c"                // Module function for 1-wire bus          (1)


/*********************************************************** ReadTemp_DS18B20 */
//Description : Read Temperature (use RB0 read temp)
void ReadTemp_DS18B20(void)
{
    byte i, buffer[9];
    byte temp,sign;

    if (touch_present()) {         // get present (reset)                    (2)
        touch_write_byte(0xCC);    // Skip ROM                               (3)
        touch_write_byte (0x44);   // Start Conversion
        delay_ms(200);             // delay 200 ms                           (4)
        touch_present();           // get present (reset)                    (5)
        touch_write_byte(0xCC);    // Skip ROM                               (6)
        touch_write_byte (0xBE);   // Read Scratch Pad

        for(i=0; i<9;i++)          // read 9 bytes                           (7)
            buffer[i] = touch_read_byte();
    }

    temp = (buffer[1]<<4)|(buffer[0]>>4);       // Temperature               (8)
    if(buffer[1]&0xF0) temp = (-1)*temp;        // Sign bit

    printf ("\f\nTemperature %d C",temp);
//    printf ("Temperature MSB:LSB %X%X ",temp,buffer[1],buffer[0]);
//    printf ("Configuration Register:%X",buffer[4]);
}

/************************************************************* Main Functions */
void main(void)
{
    while (TRUE) {
        ReadTemp_DS18B20();
        delay_ms(1000);
    }
}
/*************************** End of $Workfile: $ ******************************/
