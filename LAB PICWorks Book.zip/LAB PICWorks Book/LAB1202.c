/*******************************************************************************
* File        : LAB1202.c
* Purpose     : Voltage Reference Module
* Author      : Prajin Palangsantikul
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Copyright (c) 2006 APPSOFTTECH CO.,LTD.
*******************************************************************************/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A
#device ADC=10                    // set 10 bit ADC


/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // Serial port 


/************************************************************* Main Functions */
void main()
{
  printf("\r\nRunning Voltage ref test...\r\n\n    ");

  /** Vdd*(value/32)+Vdd/4 = 3.59375 */
  setup_vref(VREF_A2|VREF_HIGH|15);      //                                  (1)

  while(TRUE)
  ;
}
/*************************** End of $Workfile: $ ******************************/
