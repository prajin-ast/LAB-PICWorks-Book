/*******************************************************************************
* Workfile    : LAB1602.c
* Purpose     : DS1990A iButton
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Other Files :
* Ref         :
*******************************************************************************/

/*********************************************************************** NOTE */
// PIN_B0 -> iButton PIN

/******************************************************************* Includes */
#include <16F877.h>                // header file for PIC16F877A

/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP     // Configuration word
#use delay(clock=20000000)          // Change OSC here (default 20MHz)
#use rs232(baud=9600, xmit=PIN_C6,rcv=PIN_C7) // Use serial I/O port (RS232)

#include "touch.c"                  // Dallas Touch Driver   


/************************************************************* Main Functions */
void main(void)
{
   int key_iButton[7];              // key ibutton
   int i;

   while(1)
   {
      while(!touch_present()) ;     // Wait Reset pin 1-wire
      delay_ms(200);

      if(touch_present())           // pin Reset
      {
         touch_write_byte(0x0F);    // Read ROM iButton 1
         for(i=0;i<7;i++)           // Loop read data
         {
            key_iButton[i] = touch_read_byte();
         }

         printf("\f\rkey ibutton :");
         for(i=6;i>0;i--)
            printf("%X ",key_iButton[i]);
      }
   }
}
/************************** End of $Workfile: $ *******************************/
