/*******************************************************************************
* Workfile    : LAB0603.c
* Purpose     : Servo Control PWM
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : CCS C Compiler
* Target      : PIC16F877A
* Other Files :
* Ref         :
*******************************************************************************/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A


/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)

#define SERVO_PIN			PIN_C0      // pin servo control                       (1)
#define	PULSE_LEFT		2           // 2.0	ms
#define PULSE_RIGHT		1           // 1.0 ms
#define	PULSE_STOP		1500        // 1.5 ms (1500us)
#define PULSE_LOW			20          // 20.0 ms


/************************************************************** Servo Control */
/** Driver motor forware, backword, stop */
/** Clockwise */
void servo_left(void)              //                                        (2)
{
    output_high(SERVO_PIN);
    delay_ms(PULSE_LEFT);
    output_low(SERVO_PIN);
    delay_ms(PULSE_LOW);
}
/** Counterclockwise */
void servo_right(void)             //                                        (3)
{
    output_high(SERVO_PIN);
    delay_ms(PULSE_RIGHT);
    output_low(SERVO_PIN);
    delay_ms(PULSE_LOW);
}
/** Center */
void servo_stop(void)              //                                        (4)
{
    output_high(SERVO_PIN);
    delay_us(PULSE_STOP);
    output_low(SERVO_PIN);
    delay_ms(PULSE_LOW);
}

/************************************************************** Main Function */
void main()
{
    int i;

    set_tris_c(0x00);             // port c all output

    while (TRUE) {
        for (i=0;i<100;i++)       //                                         (5) 
            servo_left();
        for(i=0;i<100;i++)        //                                         (6)
            servo_right();
        for(i=0;i<100;i++)        //                                         (7)
            servo_stop();
    }
}
/************************** End of $Workfile:  $ ******************************/
