/*******************************************************************************
* Workfile    : LAB0401.c
* Purpose     : 7-Segments LED Display
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Other Files :
* Ref         :
*******************************************************************************/

/*********************************************************************** NOTE */
/*
* Configure the 7-Segments LED as follows:
* LED seg a   Pin B0
* LED seg b   Pin B1
* LED seg c   Pin B2
* LED seg d   Pin B3
* LED seg e   Pin B4
* LED seg f   Pin B5
* LED seg g   Pin B6
* LED seg dp  Pin b7
*/


/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A


/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)


/***************************************************************** Data types */
BYTE CONST LED_MAP[17] = {0x3F, 0x06, 0x5B, 0x4F, 0x66,  //0,1,2,3,4         (1)
                          0x6D, 0x7D, 0x07, 0x7F, 0x6F,  //5,6,7,8,9
                          0x77, 0x7C, 0x39, 0x5E, 0x79,  //A,b,C,d,E
                          0x71, 0x80};                   //F,.


/************************************************************* Main Functions */
void main(void)
{
    int i=0;
    
    set_tris_d(0x00);          // Set port RD all output

    while (TRUE) {
        output_d(LED_MAP[i]);  //                                            (2)
        delay_ms(1000);
        i++;                   // Count up                                   (3)
        if (i > 16)            //                                            (4)             
            i = 0;
    }
}
/*************************** End of $Workfile: $ ******************************/
