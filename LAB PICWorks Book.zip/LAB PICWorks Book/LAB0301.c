/*******************************************************************************
* Workfile    : LAB0301.c
* Purpose     : Flash an LED
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Other Files :
* Ref         :
*******************************************************************************/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A


/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)


/************************************************************* Main Functions */
void main(void)
{
    set_tris_a(0xFE);          // Set RA0 output only                        (1)

    while (TRUE) {
        output_high(PIN_A0);   // Output high to RA0                         (2)
        delay_ms(1000);        // Delay apx 1 s                              (3)  
        output_low(PIN_A0);    // Output low to RA0                          (4)
        delay_ms(1000);        // Delay apx 1 s
    }
}
/************************** End of $Workfile: $ *******************************/
