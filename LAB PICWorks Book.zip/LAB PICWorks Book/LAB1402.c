/*******************************************************************************
* File        : LAB1402.c
* Purpose     : USART Module
* Author      : Prajin Palangsantikul
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Copyright (c) 2006 APPSOFTTECH CO.,LTD.
*******************************************************************************/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A


/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)         (1)
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // Serial port               (2)

#include <stdlib.h>               //                                         (3)
#include "input.c"                //                                         (4)

char ch;                          //                                         (5)
short int RX=0;


/******************************************************************** RxD ISR */
// RS232 receive data available
#INT_RDA                          //                                         (6)
void RxD_ISR(void)
{
    ch = getc();
    RX = 1;
    output_high(PIN_A0);
}

/************************************************************* Main Functions */
void main(void)
{
    enable_interrupts(INT_RDA);   //                                         (7)
    enable_interrupts(GLOBAL);

    while (TRUE) {
        if (RX) {                 //                                         (8)
            putc(ch);
            RX = 0;
            output_low(PIN_A0);
        }
   }
}
/*************************** End of $Workfile: $ ******************************/
