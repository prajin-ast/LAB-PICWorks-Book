/*******************************************************************************
* Workfile    : LAB0702.c
* Purpose     : Scankey matrix Show on LED 7 Segments
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : CCS C Compiler
* Target      : PIC16F877A
* Ref         :
*******************************************************************************/

/*********************************************************************** NOTE */
/*
** For the black keypad
* COL0 = RB5 , COL1 = RB6 , COL2 = RB7
* ROW0 = RB1 , ROW1 = RB2 , ROW2 = RB3 , ROW3 = RB4
* RB0 not use
** Configure the LED 7 Segments as follows:
* LED seg a   Pin D0
* LED seg b   Pin D1
* LED seg c   Pin D2
* LED seg d   Pin D3
* LED seg e   Pin D4
* LED seg f   Pin D5
* LED seg g   Pin D6
* LED seg dp  Pin D7
* LED Cathode 1  Pin A0
* LED Cathode 2  Pin A1
* LED Cathode 3  Pin A2
* using input from a key matrix
*/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A


/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)

#define use_portb_kbd             // use portb key matrix
#include <kbd.c>                  // module key matrix (use the black keypad)

#define Time_Delay   1            // Delay for display LED 7 segments


/***************************************************************** Data types */
BYTE CONST LED_MAP[17] = {0x3F, 0x06, 0x5B, 0x4F, 0x66,  //0,1,2,3,4
                          0x6D, 0x7D, 0x07, 0x7F, 0x6F,  //5,6,7,8,9
                          0x77, 0x7C, 0x39, 0x5E, 0x79,  //A,b,C,d,E
                          0x71, 0x80};                   //F,.


/***************************************************************** Prototypes */
void kbd_pullup_init();
void Display_Segs(char c);
void Display( char one, char two, char three);


/************************************************************ kbd pullup init */
void kbd_pullup_init()
{
    port_b_pullups(true);         // portb pullups
}

/*************************************************************** Display_Segs */
void Display_Segs(char c)
{
    if(c=='*')                         //                                    (1)
        output_d(0x5C);                // Display "o" character              
    else 
        if(c=='#')                     //                                    (2) 
            output_d(0x76);            // Display "H" character              
        else
            output_d(LED_MAP[c-'0']);  // Display Number character           
}

/******************************************************************** Display */
/** Display Digit to 7 Segments */
void Display( char one, char two, char three)
{
    Display_Segs(one);           // Display Colum 1                          (3)
    output_low(PIN_A0);          // On
    delay_ms(Time_Delay);
    output_high(PIN_A0);         // Off

    Display_Segs(two);           // Display Colum 2                          (4)
    output_low(PIN_A1);          // On
    delay_ms(Time_Delay);
    output_high(PIN_A1);         // Off

    Display_Segs(three);         // Display Colum 3                          (5)
    output_low(PIN_A2);          // On
    delay_ms(Time_Delay);
    output_high(PIN_A2);         // Off
}

/************************************************************* Main Functions */
void main()
{
    char k, pos1, pos2, pos3;

    kbd_pullup_init();     // kbd init pullup port RB
    set_tris_d(0);         // Set port RD output all
    output_d(0);           // Clear port RD

    pos1='0';              // Set Colum 1  display 0                         (6)
    pos2='0';              // Set Colum 2  display 0 
    pos3='0';              // Set Colum 3  display 0 

    while (TRUE) {
        display(pos1,pos2,pos3);   // Display                                (7)
        k=kbd_getc();              // Get KDB
        if (k!=0) {
            pos1=pos2;             // Assign col2 to col1                    (8)
            pos2=pos3;             // Assign col3 to col2
            pos3=k;                // Set character get kbd to col3
        }
    }
}
/************************** End of $Workfile:  $ ******************************/
