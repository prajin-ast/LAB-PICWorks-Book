/*******************************************************************************
* File        : LAB1901.c
* Purpose     : RAM Buffer for UART
* Author      : Prajin Palangsantikul
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Copyright (c) 2006 APPSOFTTECH CO.,LTD.
*******************************************************************************/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A
#device *=16                      // Set pointer variable to 16 bit

/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // Serial port

/******************************************************************** Defines */
#define BUFFSIZE 10

/***************************************************************** Data types */
typedef unsigned char UCHAR;

/*****************************************************************  variables */
/** File scope variables */
UCHAR head=0 , tail=0;
BOOLEAN RX=0;
byte Buf_1[BUFFSIZE],Buf_2[BUFFSIZE];


/******************************************************************* Uart_ISR */
// Function : Uart_ISR
// Purpose  : UART Interrupt Service Routine
#int_RDA
void Uart_ISR()
{
    static char value;

    value = getc();

    if (value == '\r') {
        RX = 1;
        return;
    }

    if (tail++ < BUFFSIZE)
        Buf_1[tail] = value;
    else
        if (tail < (BUFFSIZE*2))
            Buf_2[tail%BUFFSIZE] = value;
        else
            RX = 1;
}

/**************************************************************** Read_Buffer */
// Function : Read_Buffer
// Purpose  : read data from buffer
char Read_Buffer(char * index)
{
    if (index < BUFFSIZE)
        return(Buf_1[index]);
    else
        if (index < (BUFFSIZE*2))
            return(Buf_2[index%BUFFSIZE]);
}

/************************************************************* Main Functions */
void main()
{
    char x = 0x01;
    
    // Initialize UART Interrupt
    ENABLE_INTERRUPTS(GLOBAL);
    ENABLE_INTERRUPTS(INT_RDA);

    printf("\n\rUART Interrupt\n\r");
    for (;;) {
        if (RX) {
            while (head != tail) {
                putc(Read_Buffer(head++));
                if (head >= (BUFFSIZE*2)) head = 0;
                if (tail >= (BUFFSIZE*2)) tail = 0;
            }
            printf(" [head:%d, tail:%d] \n\r",head,tail);
            RX = 0;
        }
        output_b(x);
        rotate_right(&x, 1);
        delay_ms(300);
    }
}
/*************************** End of $Workfile: $ ******************************/
