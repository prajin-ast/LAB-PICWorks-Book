/*******************************************************************************
* Workfile    : LAB0801.c
* Purpose     : External Interrupt
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Other Files :
* Ref         :
*******************************************************************************/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A


/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)


/******************************************************************** EXT ISR */
#INT_EXT                          //                                         (1)
void EXT_ISR(void)                //                                         (2)
{
    output_toggle(PIN_A0);        // output toggle
    delay_us(200);
}

/******************************************************************* Init_MCU */
/** Initialize Config MCU */
void Init_MCU(void)
{
    /** Set Interrupt */
    enable_interrupts(GLOBAL);   // Set interrupt global                     (3)
    enable_interrupts(INT_EXT);  // Set external interrupt                   (4)
    ext_int_edge(H_TO_L);        // External interrupt high to low edge      (5)

    /** Set Direction port */
    set_tris_a(0x00);            // Set port RA output
}

/************************************************************* Main Functions */
void main()
{
    Init_MCU();                   // Initialize Config MCU

    while (TRUE) {
        output_toggle(PIN_A1);    // output toggle                           (6)
        delay_ms(1000);                     
    }
}
/************************** End of $Workfile:  $ ******************************/
