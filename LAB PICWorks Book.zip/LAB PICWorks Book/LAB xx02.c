/*******************************************************************************
* Workfile    : LAB12.c
* Purpose     : Timer & 7 Segments LED
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Other Files :
* Ref         :
*******************************************************************************/

/*********************************************************************** NOTE */
/*
* Configure the LED 7 Segments as follows:
* LED seg   a   Pin D0
* LED seg   b   Pin D1
* LED seg   c   Pin D2
* LED seg   d   Pin D3
* LED seg   e   Pin D4
* LED seg   f   Pin D5
* LED seg   g   Pin D6
* LED seg   dp  Pin D7
* LED anode 1   Pin A0
* LED anode 2   Pin A1
*/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A


/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)


/***************************************************************** Data types */
BYTE CONST LED_MAP[17] = {0x3F, 0x06, 0x5B, 0x4F, 0x66,  //0,1,2,3,4
                          0x6D, 0x7D, 0x07, 0x7F, 0x6F,  //5,6,7,8,9
                          0x77, 0x7C, 0x39, 0x5E, 0x79,  //A,b,C,d,E
                          0x71, 0x80};                   //F,.
unsigned int tick  = 0;
BYTE time_sec      = 0;
BOOLEAN toggle_dsp = FALSE;


/***************************************************************** Timer0 ISR */
#INT_TIMER0
void timer0_ISR(void)
{
    tick++;
    if (tick>75) {
        if (time_sec++>=99)
            time_sec=0;
        tick = 0;
    }

    if (toggle_dsp) {
        output_d(LED_MAP[time_sec/10]);
        output_low(PIN_A1);
        output_high(PIN_A0);
        toggle_dsp = FALSE;
    } else {
        output_d(LED_MAP[time_sec%10]);
        output_low(PIN_A0);
        output_high(PIN_A1);
        toggle_dsp = TRUE;
    }
}

/******************************************************************* Init_MCU */
/** Initialize Config MCU */
void Init_MCU(void)
{
    /** Set Interrupt Timer0 */
    enable_interrupts(GLOBAL);
    enable_interrupts(INT_TIMER0);

    /** Setup Timer0 mode tick every 51.2 us => 1 s = tick 76 */
    setup_timer_0(RTCC_INTERNAL| RTCC_DIV_256);
    set_timer0(0);

    /** Set Direction port */
    set_tris_a(0xF0);          // port RA0-RA3 output, RA4-RA5 input
    set_tris_d(0x00);          // port d all output
    set_tris_c(0x00);          // port c all output
}

/************************************************************* Main Functions */
void main(void)
{
    int x=0x01;

    Init_MCU();                 // Initialize Config MCU

    output_c(0x00);             // clear port c

    while (TRUE) {
        output_c(x);
        rotate_left( &x, 1);    // rotate left
        delay_ms(500);          // delay 0.5 s
    }
}
/*************************** End of $Workfile: $ ******************************/
