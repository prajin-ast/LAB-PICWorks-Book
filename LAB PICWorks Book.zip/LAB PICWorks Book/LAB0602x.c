/*******************************************************************************
* Workfile    : LAB0602.c
* Purpose     : Stepper Motor Control (Full Step 1-Phase)
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Other Files :
* Ref         :
*******************************************************************************/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A


/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)


#define MOTOR_PIN1   PIN_C0       //                                         (1)
#define MOTOR_PIN2   PIN_C1
#define MOTOR_PIN3   PIN_C2
#define MOTOR_PIN4   PIN_C3


/***************************************************************** Prototypes */
void Delay_Seconds(int i);
void Delay_1ms(int16 i);
void fw_step(int16 step, int dl);
void rw_step(int16 step, int dl);


/************************************************************** Delay Seconds */
/** Delay Seconds */
void Delay_Seconds(int i)         //                                         (2)
{
    for (;i>0;i--) {
        delay_ms(1000);
    }
}

/******************************************************************* Delay ms */
/** Delay ms */
void Delay_1ms(int16 i)           //                                         (3)
{
    if (i<40) i = 40;             // Minimun Step (default)
    for (;i>0;i--) {
        delay_ms(1);
    }
}

/************************************************************** Motor control */
/** Driver motor forware, backword */
/** Forward Step */
void fw_step(int16 step, int dl)  //                                         (4)
{
    for (; step>0; step--) {
        output_high(MOTOR_PIN1); Delay_1ms(dl); output_low(MOTOR_PIN1);
        output_high(MOTOR_PIN2); Delay_1ms(dl); output_low(MOTOR_PIN2);
        output_high(MOTOR_PIN3); Delay_1ms(dl); output_low(MOTOR_PIN3);
        output_high(MOTOR_PIN4); Delay_1ms(dl); output_low(MOTOR_PIN4);
    }
}

/** Reward Step */
void rw_step(int16 step, int dl)  //                                         (5)
{
    for (; step>0; step--) {
        output_high(MOTOR_PIN4); Delay_1ms(dl); output_low(MOTOR_PIN4);
        output_high(MOTOR_PIN3); Delay_1ms(dl); output_low(MOTOR_PIN3);
        output_high(MOTOR_PIN2); Delay_1ms(dl); output_low(MOTOR_PIN2);
        output_high(MOTOR_PIN1); Delay_1ms(dl); output_low(MOTOR_PIN1);
    }
}

/************************************************************** Main Function */
void main()
{
    set_tris_c(0x00);          // Port C all output

    while (TRUE) {
        fw_step(10, 40);       // Clockwise
        Delay_Seconds(5);
        rw_step(10, 40);       // Counter-Clockwise
        Delay_Seconds(5);
    }
}
/************************** End of $Workfile:  $ ******************************/
