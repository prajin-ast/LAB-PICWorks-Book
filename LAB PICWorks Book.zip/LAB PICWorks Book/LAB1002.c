/*******************************************************************************
* File        : LAB1002.c
* Purpose     : Output Compare Mode (CCP Module)
* Author      : Prajin Palangsantikul
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Copyright (c) 2006 APPSOFTTECH CO.,LTD.
*******************************************************************************/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A


/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)


/****************************************************************** Variables */
int counter_compare=0;            //                                         (1)


/******************************************************************* CCP1_ISR */
#int_ccp1                         
void CCP1_ISR(void)
{
    counter_compare++;            //                                         (2)
    if (counter_compare>2) {      //                                         (3)
        output_toggle(PIN_A0);    //                                         (4)
            counter_compare=0;    //                                         (5)            
    }
}

/************************************************************* Main Functions */
void main(void)
{
    /** Set interrupt CCP1  */
    enable_interrupts(GLOBAL);
    enable_interrupts(INT_CCP1);    // pin RC2/CCP1                          (6)

    /** Setup CCP Module */
    setup_ccp1(CCP_COMPARE_SET_ON_MATCH);   //                               (7)        
    CCP_1_LOW = 0xFF;                       //                               (8)
    CCP_1_HIGH = 0xFF;                      //                               (9) 

    /** Setup Timer1 */
    setup_timer_1(T1_INTERNAL|T1_DIV_BY_8); //                              (10)
    set_timer1(0);                          //                              (11)
  
    while (TRUE)
        ;
}
/*************************** End of $Workfile: $ ******************************/
