/*******************************************************************************
* File        : LAB2001.c
* Purpose     : Advanced Move Character on LCD Module
* Author      : Prajin Palangsantikul
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Copyright (c) 2006 APPSOFTTECH CO.,LTD.
*******************************************************************************/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A

/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // Serial port

//************************************************************ LCD 4 bit mode */
// D0 = enable , D1 = rs , D2 = rw
// D4 = D4     , D5 = D5 , D6 = D6 , D7 = D7
// LCD pins D0-D3 are not used and PIC D3 is not used.
//******************************************************************************
#define DELAY_TIME  200           // Delay Constant
#include <lcd.c>                  // module lcd

char const msg_lcd[] = {" >Left & Right< "};

//******************************************************** Left/Right Message */
void LeftRight_Message(int x, int y)
{
    int i,j;

    // move message to left
    for (i=16;i>0;i--) {
        lcd_gotoxy(i,y);
        printf(lcd_putc,"%s",msg_lcd);
        delay_ms(DELAY_TIME);
    }

    for (i=1;i<16;i++) {
        lcd_gotoxy(x,y);
        for (j=i;j<16;j++)
            printf(lcd_putc,"%c",msg_lcd[j]);
        delay_ms(DELAY_TIME);
    }

    // move message to right
    for (i=15;i>0;i--) {
        lcd_gotoxy(x,y);
        for(j=i;j<16;j++)
            printf(lcd_putc,"%c",msg_lcd[j]);
        delay_ms(DELAY_TIME);
    }

    for (i=1;i<16;i++) {
        lcd_gotoxy(i,y);
        printf(lcd_putc,"%s",msg_lcd);
        delay_ms(DELAY_TIME);
    }
}

/************************************************************* Main Functions */
void main()
{
    lcd_init();                // lcd init

    while (TRUE) {
        lcd_putc("\f");           // clear screen
        lcd_gotoxy(1,1);
        printf(lcd_putc,">> TEST LCD.. <<");
        delay_ms(500);
        LeftRight_Message(1, 2);  // move message to 2nd line

        lcd_putc("\f");           // clear screen
        lcd_gotoxy(1,2);
        printf(lcd_putc,">> TEST LCD.. <<");
        delay_ms(500);
        LeftRight_Message(1, 1);  // move message to 1nd line    
    }
}
/*************************** End of $Workfile: $ ******************************/
