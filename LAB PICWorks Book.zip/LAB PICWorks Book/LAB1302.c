/*******************************************************************************
* File        : LAB1302.c
* Purpose     : CODE Memory
* Author      : Prajin Palangsantikul
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Copyright (c) 2006 APPSOFTTECH CO.,LTD.
*******************************************************************************/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A


/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // Serial port

/************************************************************* Main Functions */
void main(void)
{
    int32 addr_pm;       // address program memmory                          (1)
    int8 data;

    printf("\r\nWirte Program Memory ");

    data = 'A';

    for (addr_pm=0x1000;addr_pm<=0x101A;addr_pm++) {   //                    (2)
        // write 27 character
        write_program_eeprom(addr_pm,data);            //                    (3)
        delay_ms(10);
   }

    printf("\r\nComplete...  ");

    while(TRUE);
}
/*************************** End of $Workfile: $ ******************************/
