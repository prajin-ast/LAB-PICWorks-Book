/*******************************************************************************
* Workfile    : LAB0902.c
* Purpose     : Basic Timer1
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Other Files :
* Ref         :
*******************************************************************************/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A


/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)


/***************************************************************** Data types */
unsigned int tick=0;              //                                         (1)


/***************************************************************** Timer1 ISR */
#INT_TIMER1                       //                                         (2)
void Timer1_ISR(void)
{
    tick++;                       //                                         (3)
    if (tick>19) {                //                                         (4)
        output_toggle(PIN_A0);    // Toggle bit
        tick = 0;
    }
}

/************************************************************* Main Functions */
void main(void)
{
    enable_interrupts(GLOBAL);      // Set global interrupt
    enable_interrupts(INT_TIMER1);  // Set timer1 interrupt                  (5)

    /** Setup Timer0 mode tick every 0.05 us => 1 s = tick 20 (Overflow) */
    setup_timer_1(T1_INTERNAL | T1_DIV_BY_4);  //                             (6)
    set_timer1(0);                  // Clear Timer1

    set_tris_a(0x00);               // Set port a all output
    output_low(PIN_A0);             // Clear RA0

    while (TRUE) {                  // Loop forever
        ;
    }
}
/*************************** End of $Workfile: $ ******************************/
