/*******************************************************************************
* Workfile    : LAB0304.c
* Purpose     : LED Toggle by Switch button
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Other Files :
* Ref         :
*******************************************************************************/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A


/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)


/************************************************************* Main Functions */
void main(void)
{
    set_tris_b(0x00);          // Set port RB all output
    set_tris_a(0xFF);          // Set port RA all input

    while (TRUE) {
        if (!input(PIN_A0)) {      //                                        (1) 
            output_toggle(PIN_B0); // Output port RB0                        (2)
            delay_ms(200);         // debound switch                         (3)
        }    
    }
}
/*************************** End of $Workfile: $ ******************************/
