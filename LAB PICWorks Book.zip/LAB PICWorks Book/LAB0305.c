/*******************************************************************************
* Workfile    : LAB0305.c
* Purpose     : Two switch button
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Other Files :
* Ref         :
*******************************************************************************/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A


/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)


/************************************************************* Main Functions */
void main(void)
{
    set_tris_b(0x00);          // Set port RB all output
    set_tris_a(0x03);          // Set port RA0-RA1 input only

    while (TRUE) {
        if (!input(PIN_A0)) {      //                                        (1)
            output_high(PIN_B0);   // Output port RB0 high                   (2)
        }
        if (!input(PIN_A1)) {      //                                        (3)  
            output_low(PIN_B0);    // Output port RB0 low                    (4)
        }
        
    }
}
/*************************** End of $Workfile: $ ******************************/
