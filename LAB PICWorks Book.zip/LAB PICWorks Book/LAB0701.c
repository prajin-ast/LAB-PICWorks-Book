/*******************************************************************************
* Workfile    : LAB0701.c
* Purpose     : Scankey matrix
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Other Files :
* Ref         :
*******************************************************************************/

/*********************************************************************** NOTE */
/*
* For the black keypad
* COL0 = RB5 , COL1 = RB6 , COL2 = RB7
* ROW0 = RB1 , ROW1 = RB2 , ROW2 = RB3 , ROW3 = RB4
* RB0 not use
*/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A


/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // Serial port

#define use_portb_kbd     // use portb key matrix                            (1)
#include <kbd.c>          // module key matrix (use the black keypad)        (2)


/************************************************************ kbd pullup init */
void kbd_pullup_init()
{
    port_b_pullups(true);         // portb pullups                           (3)
}

/************************************************************* Main Functions */
void main()
{
    char k;

    kbd_pullup_init();         // pullup port b                              (4)
    set_tris_b(0x00);          // port b all output

    puts("\fReady...\n");

    while (TRUE) {
        k=kbd_getc();          //                                            (5)
        if (k!=0)              //                                            (6)
            if (k=='*')        //                                            (7)
                putc('\f');    //                                            (8)
            else
                putc(k);       //                                            (8)
    }
}
/************************** End of $Workfile:  $ ******************************/
