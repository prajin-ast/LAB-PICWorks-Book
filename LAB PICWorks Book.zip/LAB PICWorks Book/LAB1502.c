/*******************************************************************************
* File        : LAB1502.c
* Purpose     : DS1307 Real-Time Clock (I2C)
* Author      : Prajin Palangsantikul
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Copyright (c) 2006 APPSOFTTECH CO.,LTD.
*******************************************************************************/

/******************************************************************* Includes */
#include <16F877A.h>                // header file for PIC16F877A
#include <stdlib.h>                 // library for input.c

/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP     // Configuration word
#use delay(clock=20000000)          // Change OSC here (default 20MHz)
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // Serial port
#use I2C(master, sda=PIN_C4, scl=PIN_C3)        // I2C Bus module

#include "input.c"                  // library for gethex()                  (1)

/******************************************************************** Defines */
#define ADDR_DS1307        0xD0         // Address DS1307                    (2)


/***************************************************************** Data types */
typedef struct {    //                                                       (3)
  BYTE sec;         // Seconds
  BYTE min;         // Minutes
  BYTE hr;          // Hours
  BYTE day;
  BYTE date;
  BYTE month;
  BYTE year;
}DS1307_RTC;

DS1307_RTC RTC;


/***************************************************************** Prototypes */
void DS1307_Write(unsigned char ctl,unsigned char dat);
BYTE DS1307_Read(unsigned char ctl);
void DS1307_WriteDate(void);
void DS1307_WrtieTime(void);

void DS1307_ReadDate(void);
void DS1307_ReadTime(void);


/*************************************************************** DS1307 Write */
void DS1307_Write(unsigned char ctl,unsigned char dat) //                    (4)
{
    i2c_start();              // Start condition
    i2c_write(ADDR_DS1307);   // Device Address - Write
    i2c_write(ctl);           // Control byte
    i2c_write(dat);           // Write data
    i2c_stop();               // Stop condition
}

/**************************************************************** DS1307 Read */
BYTE DS1307_Read(unsigned char ctl)                     //                   (5)
{
    BYTE dat;

    i2c_start();               // Start condition
    i2c_write(ADDR_DS1307);    // Device Address - Write
    i2c_write(ctl);            // Control byte

    i2c_start();
    i2c_write(ADDR_DS1307+1);  // Device Address - Read
    dat = i2c_read(0);         // Read data , Not ACK
    i2c_stop();                // Stop condition
    return (dat);              // return data
}

/*********************************************************** DS1307 WriteDate */
void DS1307_WriteDate(void)
{
    DS1307_Write(0x04,RTC.date);
    DS1307_Write(0x05,RTC.month);
    DS1307_Write(0x06,RTC.year);
}

/*********************************************************** DS1307 WriteDate */
void DS1307_WriteTime(void)
{
    DS1307_Write(0x00,RTC.sec);
    DS1307_Write(0x01,RTC.min);
    DS1307_Write(0x02,RTC.hr);
}

/************************************************************ DS1307 ReadDate */
void DS1307_ReadDate(void)
{
    RTC.date  = DS1307_Read(0x04);
    RTC.month = DS1307_Read(0x05);
    RTC.year  = DS1307_Read(0x06);
}

/************************************************************ DS1307 ReadDate */
void DS1307_ReadTime(void)
{
    RTC.sec = DS1307_Read(0x00);
    RTC.min = DS1307_Read(0x01);
    RTC.hr  = DS1307_Read(0x02);
}

/************************************************************* DS1307 SetDate */
void DS1307_SetDate(void)
{
    printf("\n\rDate  : ");
    RTC.date= gethex();
    printf("\n\rMonth : ");
    RTC.month= gethex();
    printf("\n\rYear  : ");
    RTC.year= gethex();
}

/************************************************************* DS1307 SetTime */
void DS1307_SetTime(void)
{
    printf("\n\rHour : ");
    RTC.hr= gethex();
    printf("\n\rMin  : ");
    RTC.min= gethex();
    RTC.sec= 0x00;
}

/************************************************************** Main Function */
void main()
{
    char ch;

    printf("\f\rSet Real Time Clock (y or n):");
    ch=getchar();               //                                           (6)

    if (ch == 'y' || ch == 'Y') {
        DS1307_SetDate();       // Set Date
        DS1307_WriteDate();     // Write Date
        DS1307_SetTime();       // Set Time
        DS1307_WriteTime();     // Write Time
    }

    while (TRUE) {              //                                           (7)
        DS1307_ReadDate();
        DS1307_ReadTime();
        printf("\f\rDS1307 Real Time Clock\n");
        printf("\rDate:%2X/%2X/%2X\n",RTC.date,RTC.month,RTC.year);
        printf("\rTime:%2X:%2X:%2X",RTC.hr,RTC.min,RTC.sec);
        delay_ms(1000);
    }
}
/*************************** End of $Workfile:  $ *****************************/
