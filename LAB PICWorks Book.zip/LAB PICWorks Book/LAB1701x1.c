/*******************************************************************************
* File        : LAB1701x1.c
* Purpose     : Real Time Clock Application (DS1307)
* Author      : Prajin Palangsantikul
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Copyright (c) 2006 APPSOFTTECH CO.,LTD.
*******************************************************************************/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A

/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)
//#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // Serial port
#use I2C(master,sda=PIN_C4 ,scl=PIN_C3)  // I2C Bus module

//#include <stdlib.h>
#include "lcd.c"

#define ADDR_DS1307        0xD0         // Address DS1307

#define PIN_SELECT         PIN_B4       // Start Menu
#define PIN_UP             PIN_B5       // Select Menu up
#define PIN_DOWN           PIN_B6       // Select Menu down
#define PIN_EXIT           PIN_B7       // Exit Menu

#define MAX_SUB_MENU       5
#define MIN_SUB_MENU       0

/***************************************************************** Data types */
typedef struct {
  BYTE sec;    // Seconds
  BYTE min;    // Minutes
  BYTE hr;     // Hours
  BYTE day;
  BYTE date;
  BYTE month;
  BYTE year;
}DS1307_RTC;

DS1307_RTC RTC;

/***************************************************************** Prototypes */
void DS1307_Write(unsigned char ctl,unsigned char dat);
BYTE DS1307_Read(unsigned char ctl);
void AppMenu(void);


/******************************************************************** Ext ISR */
#int_ext
void EXT_ISR(void)            // External Interrupt (RB0)
{
    disable_interrupts(INT_EXT);
    AppMenu();
    enable_interrupts(INT_EXT);
}

/*************************************************************** DS1307 Write */
void DS1307_Write(unsigned char ctl,unsigned char dat)
{
    i2c_start();              // Start condition
    i2c_write(ADDR_DS1307);   // Device Address - Write
    i2c_write(ctl);           // Control byte
    i2c_write(dat);           // Write data
    i2c_stop();               // Stop condition
}

/**************************************************************** DS1307 Read */
BYTE DS1307_Read(unsigned char ctl)
{
    BYTE dat;

    i2c_start();               // Start condition
    i2c_write(ADDR_DS1307);    // Device Address - Write
    i2c_write(ctl);            // Control byte

    i2c_start();
    i2c_write(ADDR_DS1307+1);  // Device Address - Read
    dat = i2c_read(0);         // Read data , Not ACK
    i2c_stop();                // Stop condition
}

/************************************************************** WriteDate RTC */
void WriteDate_RTC(void)
{
    DS1307_Write(0x04,RTC.date);
    DS1307_Write(0x05,RTC.month);
    DS1307_Write(0x06,RTC.year);
}

/************************************************************** WriteTime RTC */
void WriteTime_RTC(void)
{
    DS1307_Write(0x00,RTC.sec);
    DS1307_Write(0x01,RTC.min);
    DS1307_Write(0x02,RTC.hr);
}

/******************************************************************* Read RTC */
void Read_RTC(void)
{
    RTC.date  = DS1307_Read(0x04);
    RTC.month = DS1307_Read(0x05);
    RTC.year  = DS1307_Read(0x06);
    printf(lcd_putc,"\fDate : %X/%X/%X",RTC.date,RTC.month,RTC.year);
    RTC.sec   = DS1307_Read(0x00);
    RTC.min   = DS1307_Read(0x01);
    RTC.hr    = DS1307_Read(0x02);
    printf(lcd_putc,"\nTime : %X:%X:%X",RTC.hr,RTC.min,RTC.sec);
}

void MenuSetDate(void)
{
    printf(lcd_putc,"\fDATE: __/__/__");
}

void MenuSetTime(void)
{
    printf(lcd_putc,"\fTIME: __:__:__");
}

/************************************************************* App Menu */
void AppMenu(void)
{
    int ChoiceMenu=0;
    BOOLEAN hook=1;

    lcd_putc("\f");

    do {
        if (!input(PIN_UP)) {
            delay_ms(20);           // debound
            if (ChoiceMenu++ >= MAX_SUB_MENU)
                ChoiceMenu = MIN_SUB_MENU;
            hook=1;
        }

        if (!input(PIN_DOWN)) {
            delay_ms(20);           // debound
            if (ChoiceMenu-- <= MIN_SUB_MENU)
                ChoiceMenu = MAX_SUB_MENU;
            hook=1;
        }

        if (hook) {
            hook=0;
            switch (ChoiceMenu) {
              case 0: printf(lcd_putc,"\f>> Menu 1");
              break;
              case 1: printf(lcd_putc,"\f>> Menu 2");
              break;
              case 2: printf(lcd_putc,"\f>> Menu 3");
              break;
              case 3: printf(lcd_putc,"\f>> Menu 4");
              break;
              case 4: printf(lcd_putc,"\f>> Menu 5");
              break;
              case 5: printf(lcd_putc,"\f>> Menu 6");
              break;
            }
            delay_ms(500);
        }

        if (!input(PIN_EXIT)) return;   // exit menu

    } while(input(PIN_SELECT));         // wait low

    if (ChoiceMenu == 0) MenuSetDate();
    if (ChoiceMenu == 1) MenuSetTime();
}


/************************************************************* Main Functions */
void main(void)
{
    enable_interrupts(GLOBAL);
    enable_interrupts(INT_EXT);

    lcd_init();                        // Init LCD Module
    lcd_putc("\f");

    while (TRUE) {
        Read_RTC();
        delay_ms(1000);
	}
}
/*************************** End of $Workfile: $ ******************************/
