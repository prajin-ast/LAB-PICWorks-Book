/*******************************************************************************
* File        : LAB1001.c
* Purpose     : Input Capture Mode (CCP Module)
* Author      : Prajin Palangsantikul
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Copyright (c) 2006 APPSOFTTECH CO.,LTD.
*******************************************************************************/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A


/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)


/******************************************************************* CCP1_ISR */
#int_ccp1                         //                                     (1)
void CCP1_ISR(void)               //                                     (2)
{
    output_toggle(PIN_A0);
}

/************************************************************* Main Functions */
void main(void)
{
    /** Set interrupt CCP1 */
    enable_interrupts(GLOBAL);
    enable_interrupts(INT_CCP1);    // pin RC2/CCP1                      (3)

    /** Setup CCP Module */
    setup_ccp1(CCP_CAPTURE_FE);     //                                   (4)

    /** Setup Timer1 */
    setup_timer_1(T1_INTERNAL|T1_DIV_BY_1);   //                         (5)
    set_timer1(0);                            //                         (6)
    
    set_tris_a(0x00);               // port a all output 

    while (TRUE)
        ;
}
/*************************** End of $Workfile: $ ******************************/
