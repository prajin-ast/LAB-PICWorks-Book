/*******************************************************************************
* File        : LAB1003.c
* Purpose     : PWM Mode (CCP Module)
* Author      : Prajin Palangsantikul
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Copyright (c) 2006 APPSOFTTECH CO.,LTD.
*******************************************************************************/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A


/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)


/******************************************************************* CCP1_ISR */
#int_ccp1
void CCP1_ISR(void)
{
    ;                              //                                        (1)
}

/************************************************************* Main Functions */
void main()
{
    unsigned int16 duty=0;

    /** Set port output for PWM Mode */
    set_tris_c(0x00);               // port C output all                     (2)

    /** Set interrupt CCP1  */
    enable_interrupts(GLOBAL);
    enable_interrupts(INT_CCP1);    //pin RC2/CCP1

    setup_ccp1(CCP_PWM);            // Setup CCP Module                      (3)

    /** Setup Timer2
     The cycle time will be (1/clock)*4*t2div*(period+1)
     In this program clock=20000000 and period=255
       =(1/20000000)*4*16*256= 819.2 us or 1.2 khz
	*/
    setup_timer_2(T2_DIV_BY_16, 255, 1);   //                                (4)
    set_timer2(0);                         //                                (5)

    while (TRUE) {
        duty = duty + 50;                  //                                (6)
        set_pwm1_duty(duty);               //                                (7)
        delay_ms(500);                     //                                (8)
    }
}
/*************************** End of $Workfile: $ ******************************/
