/*******************************************************************************
* Workfile    : LAB0306.c
* Purpose     : Two switch button V2
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Other Files :
* Ref         :
*******************************************************************************/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A


/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)


/************************************************************* Main Functions */
void main(void)
{
    BOOLEAN sw1=0, sw2=0;
    
    set_tris_b(0x00);          // Set port RB all output
    set_tris_a(0x03);          // Set port RA0,RA1 input only

    while (TRUE) {
        if (!input(PIN_A0)) {      //                                        (1)  
            sw1 = 1;               //                                        (2)
            delay_us(200);
        }
        if (!input(PIN_A1)) {      //                                        (3)  
            sw2 = 1;               //                                        (4)
            delay_us(200);                
        }      
        if (sw1 && sw2) {          //                                        (5)
            output_high(PIN_B0);
            delay_ms(1000);    
            output_low(PIN_B0);
            sw1 = 0;
            sw2 = 0;
        }       
    }
}
/*************************** End of $Workfile: $ ******************************/
