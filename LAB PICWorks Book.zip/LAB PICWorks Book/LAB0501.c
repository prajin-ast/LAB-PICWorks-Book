/*******************************************************************************
* Workfile    : LAB0501.c
* Purpose     : LCD Display (4bit Mode)
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Other Files :
* Ref         :
*******************************************************************************/

/*********************************************************************** NOTE */
/*
* * LCD 4 bit mode
* RD0 = enable , RD1 = rs , RD2 = rw
* RD4 = D4     , RD5 = D5 , RD6 = D6 , RD7 = D7
* LCD pins D0-D3 are not used and PIC RD3 is not used.
*/


/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A


/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)


/*********************************************************** Library function */
#include <lcd.c>                  // Driver for common LCD modules           (1)


/************************************************************* Main Functions */
void main()
{
    unsigned int i=255;

    lcd_init();                      // LCD init                             (2)
    lcd_putc("\fLCD Ready...\n");    // use function lcd_putc()              (3)
    delay_ms(1000);

    /** use function printf() + lcd_putc() */
    printf(lcd_putc,"\f<<Countdown...>>");
    printf(lcd_putc,"\nCount..>> ");

    while (TRUE) {
        lcd_gotoxy(11,2);             //                                     (4)
        printf(lcd_putc,"%u",i--);
        delay_ms(1000);
    }
}
/*************************** End of $Workfile: $ ******************************/
