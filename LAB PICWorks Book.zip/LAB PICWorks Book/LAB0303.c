/*******************************************************************************
* Workfile    : LAB0303.c
* Purpose     : Ping-Pong LED Display
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Other Files :
* Ref         :
*******************************************************************************/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A


/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)


/************************************************************* Main Functions */
void main(void)
{
    unsigned int num[]={1};    //                                            (1)
    BOOLEAN shift_lr=1;        //                                            (2)

    set_tris_b(0x00);          // Set port RB all output

    while (TRUE) {
    
        if (shift_lr) {
            output_b(num[0]);      // Output port RB                         (3)
            shift_left(num,1,0);   // Shift left                             (4)
        } else {                    
            output_b(num[0]);      // Output port RB
            shift_right(num,1,0);  // Shift right                            (5)
        }    
        delay_ms(500);             // Delay apx 0.5 s                        (6)
                
        if (num[0] == 0x80)        // Set to shift right                     (7)
              shift_lr=0;
        if (num[0] == 0x01)        // Set to shift left                      (8)
              shift_lr=1;
    }
}
/*************************** End of $Workfile: $ ******************************/
