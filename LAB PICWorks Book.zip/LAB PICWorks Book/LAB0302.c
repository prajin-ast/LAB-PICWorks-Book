/*******************************************************************************
* Workfile    : LAB0302.c
* Purpose     : Binary Number LED
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Other Files :
* Ref         :
*******************************************************************************/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A


/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)


/************************************************************* Main Functions */
void main(void)
{
    unsigned int num=0;        //                                            (1) 
    
    set_tris_b(0x00);          // Set port RB all output                     (2)

    while (TRUE) {
        output_b(num);         // Output port RB                             (3)
        num = num + 1;         // Count number                               (4)
        delay_ms(2000);        // Delay apx 2 s                              (5)
    }
}
/*************************** End of $Workfile: $ ******************************/
