/*******************************************************************************
* File        : LAB2201.c
* Purpose     : PCF8591 ADC/DAC I2C
* Author      : Prajin Palangsantikul
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Copyright (c) 2006 APPSOFTTECH CO.,LTD.
*******************************************************************************/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A

/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // Serial port
#use i2c(master,SDA=PIN_C4, SCL=PIN_C3)         // I2C Bus module

/****************************************************************** Constants */
#define PCF8591_ID  0x90  // 10010000, PCF8591:000 Slave Address (bit1-bit3)


//************************************************************* PCF8591_Write */
// Description : PCF8591 Write
void PCF8591_DAC(int dat)
{
    i2c_start();               // Start condition
    i2c_write(PCF8591_ID);     // Device address
    i2c_write(0x44);           // enable DAC (command)
    i2c_write(dat); 		   // Send data
    i2c_stop();                // Stop condition
}

/************************************************************* Main Functions */
void main(void)
{
    unsigned int8 i;

    printf("\r\n\nPCF8591 ADC/DAC I2C Start....   ");
    set_tris_b(0x00);
    delay_ms(5000);

    output_high(PIN_B0);
    PCF8591_DAC(0x36);          // analog output 1.0V
    delay_ms(5000);
    output_low(PIN_B0);
    delay_ms(1000);

    output_high(PIN_B0);
    PCF8591_DAC(0xFF);          // analog output 4.98V
    delay_ms(5000);

    for (i=0x01; i<0xFF; i++) {
        PCF8591_DAC(i++);       // increment analog
        output_high(PIN_B0);
        delay_ms(1000);
        output_low(PIN_B0);
        delay_ms(1000);
    }
    
    while (TRUE);           // Loop forever
}
/*************************** End of $Workfile: $ ******************************/
