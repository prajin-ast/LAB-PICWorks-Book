/*******************************************************************************
* Workfile    : LAB0502.c
* Purpose     : Custom LCD Character
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Other Files :
* Ref         :
*******************************************************************************/

/*********************************************************************** NOTE */
/*
* * LCD 4 bit mode
* RD0 = enable , RD1 = rs , RD2 = rw
* RD4 = D4     , RD5 = D5 , RD6 = D6 , RD7 = D7
* LCD pins D0-D3 are not used and PIC RD3 is not used.
*/


/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A


/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)


/*********************************************************** Library function */
#include <lcd.c>                  // module lcd


/**************************************************************** LCD_Command */
/** Description : LCD Command */
void LCD_Command(int cm)          //                                         (1)
{
   lcd_send_byte(0,cm);
}

/***************************************************************** CharTo_LCD */
/** Download custom char to LCD */
void CharTo_LCD(void)             //                                         (2)
{
    BYTE i,j;
    BYTE CGRAM=0x40;
    BYTE const MouthSmile[4][8] = {
        {0x0E,0x1F,0x1F,0x1F,0x1F,0x1F,0x0E,0x00},   // Mouth 0
        {0x0E,0x1F,0x1F,0x18,0x1F,0x1F,0x0E,0x00},   // Mouth 1
        {0x0E,0x1F,0x1C,0x18,0x1C,0x1F,0x0E,0x00},   // Mouth 2
        {0x00,0x0A,0x0A,0x00,0x11,0x0E,0x06,0x00}    // Smile
    };

    for (i=0;i<4;i++) {
        for (j=0;j<8;j++) {
            LCD_Command(CGRAM);     // Custom character RAM
            lcd_send_byte(1,MouthSmile[i][j]);
            CGRAM = CGRAM+1;
        }
    }
}

/************************************************************** LCD_Animation */
/** Animation */
void LCD_Animation(void)  //                                                 (3)
{
    int i;

    LCD_Command(0x80);    // DDRAM address of line 1
    LCD_Command(0x01);    // clear the LCD
    LCD_Command(0x02);    // move cursor to home position

    /** set cursor direction to right, without a display shift. */
    LCD_Command(0x06);

    /** show animation */
    for (;;)
    for (i=0;i<4;i++) {
        lcd_gotoxy(i+1,1);
        lcd_putc(i);
        delay_ms(500);
        LCD_Command(0x01);	// clear the LCD
   }
}

/************************************************************* Main Functions */
void main()
{
    lcd_init();             // LCD initialize

    CharTo_LCD();           // Creating custom lcd characters
    LCD_Animation();        // Animation show
}
/*************************** End of $Workfile: $ ******************************/
