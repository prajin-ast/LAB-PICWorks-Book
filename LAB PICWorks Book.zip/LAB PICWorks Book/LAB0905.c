/*******************************************************************************
* Workfile    : LAB0905.c
* Purpose     : Counter 1
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Other Files :
* Ref         :
*******************************************************************************/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A


/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)


/***************************************************************** Timer1 ISR */
#INT_TIMER1                       
void timer1_ISR(void)             
{
    output_toggle(PIN_A0);        // Output toggle A0                        (1) 
    set_timer1(65530);            // Set Count 65530                         (2)
}

/************************************************************* Main Functions */
void main()
{
    /** Set Interrupt */
    enable_interrupts(GLOBAL);
    enable_interrupts(INT_TIMER1);

    /** Setup Counter1 mode with 1 prescaler */
    setup_timer_1(T1_EXTERNAL| T1_DIV_BY_1);  //                             (3)                       
    set_timer1(65530);           // Start Count 65530                        (4)

    /** Set Direction port */
    set_tris_c(0x01);          // Port RC0 input only                        (5)
    set_tris_a(0xF0);          // Port RA0 - RA3 output only                 (6)

    output_low(PIN_A0);        // Clear RA0

    while (TRUE) {             // Loop forever
        ;
    }
}
/************************** End of $Workfile:  $ ******************************/
