/*******************************************************************************
* Workfile    : LAB0703.c
* Purpose     : Scankey matrix Show on Module LCD
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : CCS C Compiler
* Target      : PIC16F877A
* Ref         :
*******************************************************************************/

/*********************************************************************** NOTE */
/*
* * For the black keypad
* COL0 = RB5 , COL1 = RB6 , COL2 = RB7
* ROW0 = RB1 , ROW1 = RB2 , ROW2 = RB3 , ROW3 = RB4
* RB0 not use
* * LCD 4 bit mode
* D0 = enable , D1 = rs , D2 = rw
* D4 = D4     , D5 = D5 , D6 = D6 , D7 = D7
* LCD pins D0-D3 are not used and PIC D3 is not used.
*/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A


/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)

#include <lcd.c>                  // module lcd                              (1)

#define use_portb_kbd             // use portb key matrix                    (2) 
#include <kbd.c>                  // module key matrix (use the black keypad)


/************************************************************ kbd pullup init */
void kbd_pullup_init()
{
    port_b_pullups(true);         // portb pullups
}

/************************************************************* Main Functions */
void main()
{
    char k;

    kbd_pullup_init();         // pullup port b                              (3) 

    lcd_init();                // lcd init                                   (4)
    lcd_putc("\fReady...\n");
    
    while (TRUE) {
        k=kbd_getc();          //                                            (5)
        if (k!=0)
            if (k=='*')                                                      (6)
                lcd_putc('\f');
            else
                lcd_putc(k);
    }
}
/************************** End of $Workfile:  $ ******************************/
