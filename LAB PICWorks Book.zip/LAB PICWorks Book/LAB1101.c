/*******************************************************************************
* File        : LAB1101.c
* Purpose     : ADC Module
* Author      : Prajin Palangsantikul
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Copyright (c) 2006 APPSOFTTECH CO.,LTD.
*******************************************************************************/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A
#device ADC=10                    // set 10 bit ADC                          (1)


/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)  // Serial port 

/************************************************************* Main Functions */
void main()
{
  int16 read_adc;

  setup_adc_ports(RA0_ANALOG);     // A0                                     (2)
  setup_adc(ADC_CLOCK_INTERNAL);   // Frc                                    (3)
  set_adc_channel(0);              // (AN0 or RA0)                           (4)

  while(1)
  {
	read_adc = read_adc();         //                                        (5)
	printf("\fADC %lX  Volts = %f  ",read_adc,read_adc * (5.0/1024));
    delay_ms(100);
   }
}
/*************************** End of $Workfile: $ ******************************/
