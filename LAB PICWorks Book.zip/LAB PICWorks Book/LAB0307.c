/*******************************************************************************
* Workfile    : LAB0307.c
* Purpose     : Two switch button V3
* Copyright   : appsofttech co.,ltd.
* Author      : Prajin Palangsantikul
* Email       : prajin@appsofttech.com
* Compiler    : CCS C Compiler
* Target      : PIC16F
* Other Files :
* Ref         :
*******************************************************************************/

/******************************************************************* Includes */
#include <16F877A.h>              // header file for PIC16F877A


/************************************************ Setting configuration fuses */
#fuses HS,NOWDT,NOPROTECT,NOLVP   // Configuration word
#use delay(clock=20000000)        // Change OSC here (default 20MHz)


/************************************************************* Main Functions */
void main(void)
{
    int sw1, sw2;

    sw1 = 0;
    sw2 = 0;

    while (1) {

        if(!input(PIN_A1))              // if key down                       (1)
        {
            sw2 = sw2 + 1;              // counter up
            while(!input(PIN_A1))       // wait for key up
            {
                if(sw1 == 1)            // toggle wait for key up
                {
                   output_high(PIN_B0);
                   delay_ms(100);
                   output_low(PIN_B0);
                   delay_ms(100);
                }
            }
        }

        if(!input(PIN_A0))              // if key down                       (2)
        {
            sw1 = 1;
        }

        if(sw2 == 1)                    //                                   (3)
        {
            output_high(PIN_B1);        // On
        }
        if(sw2 == 2)
        {
            output_high(PIN_B2);        // On
        }
        if(sw2 == 3)
        {
            output_high(PIN_B3);        // On
        }
        if(sw2 == 4)
        {
            output_high(PIN_B4);        // On
        }

        if(sw2 == 5)                    //                                   (4)
        {
            sw1 = 0;                    // Clear data
            sw2 = 0;
            output_low(PIN_B1);         // Off all
            output_low(PIN_B2);
            output_low(PIN_B3);
            output_low(PIN_B4);
        }

        if(sw1 == 1)                    // toggle
        {
            output_high(PIN_B0);
            delay_ms(50);
            output_low(PIN_B0);
            delay_ms(50);
        }
  }
}
/*************************** End of $Workfile: $ ******************************/
